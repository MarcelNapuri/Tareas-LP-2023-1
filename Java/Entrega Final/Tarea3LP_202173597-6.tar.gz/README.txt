Marcel Silva Napuri
202173597-6

Instrucciones:
    - Para compilar el programa correctamente, dentro de una carpeta cualquiera (puede ser desde Tarea3LP_202173597-6) debe existir una carpeta llamada 
    "JavaHack" donde deben estar todos los archivos .java. El archivo makefile debe estar fuera de esta carpeta
	- Ejecutar en terminal: make 
	- Posteriormente se crearan los archivos compilados .class en la carpeta JavaHack
    - Para ejecutar el programa escriba en la terminal: java JavaHack.JavaHack
	- realice las acciones que le indique el programa, evite usar números float y mayusculas al escribir 

Detalles adicionales:
    -Para eliminar los archivos compilados use make clean
    -Para el compilador se utilizó openjdk 11.0.19
