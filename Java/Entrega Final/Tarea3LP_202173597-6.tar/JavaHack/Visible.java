package JavaHack;

public interface Visible {
    char getRepresentacion();
}
