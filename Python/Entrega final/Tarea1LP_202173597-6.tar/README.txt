Marcel Alejandro Silva Napuri
202173597-6

Instrucciones:
	- Ejecutar en terminal: python Formatter.py
	- Por defecto debe leer dos archivos de texto cuyos nombres son: "config.txt" y "codigo.txt"
	- Al terminar de ejecutar, se crea un archivo de texto llamado "formateado.txt"

Detalles adicionales:
	- El programa reconoce y formatea el codigo de sentencias tales como: funcion main, declaracion, operaciones unarias y binarias,
	condicionales y ciclos
	- El programa detecta algunos errores básicos en la sintaxis.
 