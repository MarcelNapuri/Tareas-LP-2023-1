Marcel Silva Napuri
202173597-6

Instrucciones:
	-Tarea desarrollada en SWI-Prolog (threaded, 64 bits, version 9.0.4)
	-el codigo funciona a través del terminal interactivo de SWI Prolog, cargando el archivo mediante
	 consult('DireccionDelArchivo/main.pl')    

Detalles adicionales:
	-al preguntar por las variables en las funciones, se dee usar ';' para mostrar mas de una respuesta
	-la funcion puedellegar al preguntar por variables, por ejemplo puedellegar(a,X) en ocasiones mostrara más de una vez
	 la misma respuesta, se debe escribir ';' hasta que aparezcan todas
    