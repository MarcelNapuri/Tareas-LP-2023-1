Marcel Silva Napuri
202173597-6

Instrucciones:
	- Ejecutar en terminal: make 
	- Posteriormente se creara un archivo main que se debe ejecutar: ./main
	- Para controlar el programa, se tiene las siguientes funciones: mkdir, touch, write, cat, ls y mapdir
	- Para terminar la ejecucion, se debe escribir en la consola: close 

Detalles adicionales:
	- No es necesario agregar ningun simbolo adicional al escribir las instrucciones por consolas
	- No es necesario crear un nodo principal (raiz) para posteriormente controlar el programa, al ejecutar se creara uno por defecto
	- Puede escribir close en cualquier momento de la ejecucion, no se debe preocupar por su posicion en los directorios